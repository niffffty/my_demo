#ifndef _elec_h
#define _elec_h

#include "headfile.h"

extern uint16 elec_data[8];

void elec_init(void);
void elec_get(void);
void elec_calculate(void);

#endif
