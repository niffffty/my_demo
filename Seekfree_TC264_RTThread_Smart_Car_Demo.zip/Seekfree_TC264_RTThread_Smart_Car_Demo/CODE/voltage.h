/*
 * voltage.h
 *
 *  Created on: 2023��4��14��
 *      Author: Dell
 */

#ifndef CODE_VOLTAGE_H_
#define CODE_VOLTAGE_H_

void voltage_init(void);
void voltage_entry(void *parameter);

float get_voltage(void);
void monitor_voltage(void);

#endif /* CODE_VOLTAGE_H_ */
