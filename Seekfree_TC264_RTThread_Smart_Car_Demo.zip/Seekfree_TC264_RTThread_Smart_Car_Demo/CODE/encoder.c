#include "headfile.h"

#define ENCODER1_GPT		    GPT12_T2
#define ENCODER1_A_PLUS			GPT12_T2INB_P33_7
#define ENCODER1_B_DIR			GPT12_T2EUDB_P33_6

int16 encoder1;

void encoder_init(void)
{
    gpt12_init(ENCODER1_GPT, ENCODER1_A_PLUS, ENCODER1_B_DIR);  //��ʱ����ʼ��
}


void encoder_get(void)
{
    encoder1 = gpt12_get(ENCODER1_GPT);
    gpt12_clear(ENCODER1_GPT);  //��ռ�����
}
