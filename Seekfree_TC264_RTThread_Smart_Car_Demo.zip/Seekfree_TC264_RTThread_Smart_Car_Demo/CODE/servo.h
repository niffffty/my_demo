#ifndef CODE_SERVO_H_
#define CODE_SERVO_H_

#include "headfile.h"

void servo_init(void);

#endif /* CODE_SERVO_H_ */
