#include "headfile.h"


    //��ؼ��
uint16 valtage_adc = 0;
float valtage_now = 0;
float val=0;
#define BUZZER_PIN          P33_10

void voltage_init(void){
    rt_thread_t tid;

    adc_init(ADC_0, ADC0_CH11_A11); //��ʼ��adc

    gpio_init(P20_8, GPO, 1, PUSHPULL);//��ʼ��led
    gpio_init(P20_9, GPO, 1, PUSHPULL);

    gpio_init(BUZZER_PIN, GPO, 0, PUSHPULL);    //��ʼ��������
    gpio_set(BUZZER_PIN, 0);    //�رշ�����

    tid=rt_thread_create("my_battery",voltage_entry,RT_NULL,256,30,30);//���ȼ�=30  (0-32)
    if(RT_NULL!=tid){
            rt_thread_startup(tid);//�����߳�
     }
}

//�߳����
void voltage_entry(void *parameter){

    while(1){
        val=get_voltage()-0.31; //У׼�ɼ����ĵ�ѹ
//        printf("\r\nBattery Valtage is : %2.2f. (0V-12V)", val);
        if(val<11.40){
//            gpio_set(P33_10, 1);    //�򿪷�����
            rt_mb_send(buzzer_mailbox, 5000);
        }

        rt_thread_delay(1000);
    }

}






float get_voltage(void){
    valtage_adc = adc_convert(ADC_0, ADC0_CH11_A11, ADC_12BIT);
    valtage_now = 36.3 * valtage_adc / 4096;
//    printf("\r\nBattery Valtage is : %2.2f. (0V-12V)", valtage_now-0.31);

    return valtage_now;
}

void monitor_voltage(void){

    val=get_voltage()-0.31; //У׼�ɼ����ĵ�ѹ
    printf("\r\nBattery Valtage is : %2.2f. (0V-12V)", val);
    if((val-12.70)<0){
//        printf("\nval\n");
       gpio_set(P20_9, 1);    //�򿪷�����
       rt_thread_mdelay(100);  //��ʱ
       gpio_set(P20_9, 0);    //�رշ�����
    }
}






