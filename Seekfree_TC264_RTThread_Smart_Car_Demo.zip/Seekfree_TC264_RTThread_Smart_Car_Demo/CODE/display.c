#include "headfile.h"
#include "encoder.h"
#include "display.h"


extern int16 encoder1;
extern float Speed_kp;
extern float Speed_ki;
extern uint16 duty;
void display_entry(void *parameter)
{
    while(1)
    {
        //��ʾ����ͷͼ��
        lcd_showint16(0,0,encoder1);//xΪint16����
        lcd_showfloat(0,1,Speed_kp,2,1);
        lcd_showfloat(0,2,Speed_ki,2,1);
        lcd_showint16(0,3,duty);


//        ips200_showint16(0, 8, icm_gyro_x);
//        ips200_showint16(0, 9, icm_acc_x);
//        ips200_showint16(0, 10, encoder1);

        rt_thread_mdelay(1);
    }
    
}






void display_init(void)
{
    rt_thread_t tid;
    
    //��ʼ����Ļ
    lcd_init();
    lcd_clear(BLACK);
    
    //������ʾ�߳� ���ȼ�����Ϊ6
    tid = rt_thread_create("display", display_entry, RT_NULL, 512, 30, 100);
    
    //������ʾ�߳�
    if(RT_NULL != tid)
    {
        rt_thread_startup(tid);
    }
}
