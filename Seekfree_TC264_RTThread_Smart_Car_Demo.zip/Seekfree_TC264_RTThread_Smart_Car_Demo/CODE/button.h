#ifndef _button_h
#define _button_h

#include "headfile.h"

void button_init(void);

#endif
