#ifndef _timer_pit_h
#define _timer_pit_h

#include "headfile.h"

void timer_pit_init(void);

#endif